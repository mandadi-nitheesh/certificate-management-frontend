import React from "react";
import { render, fireEvent, screen, waitFor } from "@testing-library/react";
import UserDataForm from "../components/UserDataForm";

describe("UserDataForm Component", () => {
  const formData = {
    commonName: "",
    organization: "",
    organizationalUnit: "",
    country: "",
    state: "",
    locality: "",
    emailAddress: "",
    certificateType: "SelfSigned",
  };

  it("should render form fields and buttons correctly", () => {
    render(
      <UserDataForm
        formData={formData}
        validationErrors={{}}
        handleInputChange={() => {}}
        handleSubmit={() => {}}
        handleReset={() => {}}
      />
    );

    expect(screen.getByLabelText("Common Name (CN)")).toBeInTheDocument();
    expect(screen.getByLabelText("Organization (O)")).toBeInTheDocument();
    expect(screen.getByLabelText("Email Address (emailAddress)")).toBeInTheDocument();
    expect(screen.getByText("Submit")).toBeInTheDocument();
    expect(screen.getByText("Reset")).toBeInTheDocument();
  });
  
  it("should not display validation errors for valid input", async () => {
    render(
      <UserDataForm
        formData={formData}
        validationErrors={{}}
        handleInputChange={() => {}}
        handleSubmit={() => {}}
        handleReset={() => {}}
      />
    );

    const commonNameInput = screen.getByLabelText("Common Name (CN)");
    fireEvent.change(commonNameInput, { target: { value: "John Doe" } });

    const organizationInput = screen.getByLabelText("Organization (O)");
    fireEvent.change(organizationInput, { target: { value: "Company Inc" } });

    const emailAddressInput = screen.getByLabelText("Email Address (emailAddress)");
    fireEvent.change(emailAddressInput, { target: { value: "john@example.com" } });

    fireEvent.click(screen.getByText("Submit"));

    await waitFor(() => {
      expect(screen.queryByText("Common Name should contain alphabets only")).not.toBeInTheDocument();
    });

    await waitFor(() => {
      expect(screen.queryByText("Organization should contain alphanumeric characters and spaces only")).not.toBeInTheDocument();
    });

    await waitFor(() => {
      expect(screen.queryByText("Invalid email address")).not.toBeInTheDocument();
    });

    expect(screen.getByText("Reset")).toBeInTheDocument();
  });
});