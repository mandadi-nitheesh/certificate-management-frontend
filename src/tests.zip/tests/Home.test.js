import React from 'react';
import { render, screen } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import Home from '../components/Home';

describe('Home Component', () => {
  it('renders the header and main content', () => {
    render(
      <Router>
        <Home />
      </Router>
    );

    // Ensure that the header is rendered
    expect(screen.getByText('Certificate Management System')).toBeInTheDocument();

    // Ensure that the main content is rendered
    expect(
      screen.getByText('Manage x.509v3 Certificates Safely and Securely')
    ).toBeInTheDocument();
  });

  it('renders key features', () => {
    render(
      <Router>
        <Home />
      </Router>
    );

    // Ensure that all key features are rendered
    expect(screen.getByText('Key Features')).toBeInTheDocument();
    expect(screen.getByText('Certificate Generation')).toBeInTheDocument();
    expect(screen.getByText('Search and Retrieve')).toBeInTheDocument();
    expect(screen.getByText('Renewal of Certificates')).toBeInTheDocument();
  });

  it('renders feature icons', () => {
    render(
      <Router>
        <Home />
      </Router>
    );

    // Ensure that all feature icons are rendered
    expect(screen.getByAltText('Certificate Icon')).toBeInTheDocument();
    expect(screen.getByAltText('Search Icon')).toBeInTheDocument();
    expect(screen.getByAltText('Renew Icon')).toBeInTheDocument();
  });

  it('renders feature descriptions', () => {
    render(
      <Router>
        <Home />
      </Router>
    );

    // Ensure that all feature descriptions are rendered
    expect(
      screen.getByText('Easily generate certificates for individuals or organizations.')
    ).toBeInTheDocument();
    expect(
      screen.getByText('Quickly search and retrieve certificates when needed.')
    ).toBeInTheDocument();
    expect(screen.getByText('Effortlessly renew certificates with our system.')).toBeInTheDocument();
  });

    it("renders footer correctly", () => {
        render(
            <Router>
              <Home />
            </Router>
          );
  
      // Find the footer element by its text content
      const footer = screen.getByText(/CASE STUDY:- Certificate Management System by Group 1/i);
  
      // Assert that the footer element is in the document
      expect(footer).toBeInTheDocument();
  });
});